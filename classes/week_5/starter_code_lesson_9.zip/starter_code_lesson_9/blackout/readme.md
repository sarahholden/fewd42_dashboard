Instructions:

When the user clicks on the "light switch" button, if the body has the class "dark" it should be removed. If it does not have the class, it should be added.

You'll need to look up the hasClass method